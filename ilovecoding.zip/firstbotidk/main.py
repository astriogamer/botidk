import discord
import os
import time
import discord.ext
from discord.utils import get
from discord.ext import commands, tasks
from discord.ext.commands import has_permissions,  CheckFailure, check
#^ basic imports for other features of discord.py and python ^
TOKEN = 'ODQ0MTAzNDc1ODg1NjM3NjQz.YKNinw._zE5dYTw4Z280co5jDADe3HpG4g'

client = discord.Client()

client = commands.Bot(command_prefix = '.') #prefix

@client.event
async def on_ready():
    print("iknowhowtocodeyes") #will print "online message" in the console when the bot is online
    
    
@client.command()
async def ping(ctx):
    await ctx.send("pong!") #simple command so that when you type "!ping" the bot will respond with "pong!"
@client.command()
async def kick(ctx, member : discord.Member):
    try:
        await member.kick(reason=None)
        await ctx.send("kicked "+member.mention) #kick command
    except:
        await ctx.send("Imagine not knowing how to set permissions")
@client.command()
async def roll(ctx):
    await ctx.send("https://media.tenor.com/images/461a7c321425e447814ec90bb0a72faa/tenor.gif") #dk!"
@client.command()
@commands.has_permissions(administrator=True)
async def ban(ctx, member : discord.Member):
    try:
        await member.ban(reason=None)
        await ctx.send(member.mention +"Got expired" +"https://i.imgur.com/65c8kAl.gif") #kick command
    except:
        await ctx.send("Give yourself 3 seconds to think about this")
@client.command()
@commands.has_permissions(administrator=True)
async def unban(ctx, *, member):
  banned_users = await ctx.guild.bans()
  member_name, member_discriniator = member.split('#')

  for ban_entry in banned_users:
      user = ban_entry.user

      if (user.name, user.discriminator) == (member_name, member_discriniator):
        await ctx.guild.unban(user)
        await ctx.send(f'Unbanned {user.name}#{user.discriminator}')
        return
@client.command()
async def bane(ctx):
    await ctx.send("who do you want to ban?" +"https://i.imgur.com/O3DHIA5.gif") #just looks
@client.command()
@commands.has_permissions(administrator=True)
async def nuke(ctx, channel_name):
    channel_id = int(''.join(i for i in channel_name if i.isdigit())) 
    existing_channel = client.get_channel(channel_id)
    if existing_channel:
        await existing_channel.clone(reason="Has been nuked")
        await existing_channel.delete()
    else:
        await ctx.send(f'No channel named **{channel_name}** was found')
@client.command()
@commands.has_permissions(manage_messages=True)
async def mute(ctx, member: discord.Member, *, reason=None):
  guild = ctx.guild
  mutedRole = discord.utils.get(guild.roles, name="Muted")

  if not mutedRole:
    mutedrole = await ctx.send("Theres no mute role wtf???")

@client.command
async def unmute(ctx, member: discord.Member):
  mutedRole = discord.utils.get(ctx.guild.roles, name="Muted")
  await member.remove_roles(mutedRole)
  await ctx.send(f"Unmuted {member.mention}")
client.run(TOKEN)
